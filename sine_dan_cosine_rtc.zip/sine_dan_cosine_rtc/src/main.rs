use std::f64::consts::PI;

struct TaylorSeries;

impl TaylorSeries {
    // Fungsi untuk menghitung faktorial
    fn factorial(n: u64) -> f64 {
        if n == 0 {
            1.0
        } else {
            (1..=n).fold(1.0, |acc, i| acc * i as f64)
        }
    }

    // Fungsi untuk menghitung sine menggunakan deret Taylor
    fn sin(x: f64, n_terms: u32) -> f64 {
        let mut result = 0.0;
        for n in 0..n_terms {
            let term = (-1.0_f64).powi(n as i32) * x.powi(2 * n as i32 + 1) 
                      / Self::factorial(2 * n as u64 + 1);
            result += term;
        }
        result
    }

    // Fungsi untuk menghitung cosine menggunakan deret Taylor
    fn cos(x: f64, n_terms: u32) -> f64 {
        let mut result = 0.0;
        for n in 0..n_terms {
            let term = (-1.0_f64).powi(n as i32) * x.powi(2 * n as i32) 
                      / Self::factorial(2 * n as u64);
            result += term;
        }
        result
    }
}

fn main() {
    let n_terms = 10;  // Jumlah suku dalam deret Taylor
    let steps = 8;     // Jumlah sudut yang dihitung (0° sampai 360°)
    let mut results = Vec::new(); // Menyimpan hasil dalam bentuk (angle, sin, cos)

    // Hitung sin dan cos untuk beberapa sudut (0 sampai 2π)
    for i in 0..=steps {
        let angle = (2.0 * PI * i as f64) / steps as f64;  // Sudut dalam radian
        let sin_x = TaylorSeries::sin(angle, n_terms);
        let cos_x = TaylorSeries::cos(angle, n_terms);
        results.push((angle, sin_x, cos_x));
    }

    // Tampilkan hasil dalam bentuk tabel
    println!("| Angle (rad) | sin(x)      | cos(x)      |");
    println!("|-------------|-------------|-------------|");
    for (angle, sin_x, cos_x) in results {
        println!("| {:.4}      | {:.8}  | {:.8}  |", angle, sin_x, cos_x);
    }
}